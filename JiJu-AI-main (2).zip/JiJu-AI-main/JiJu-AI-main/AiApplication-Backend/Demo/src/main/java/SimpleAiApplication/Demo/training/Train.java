package SimpleAiApplication.Demo.training;

import org.springframework.ai.chat.model.ChatModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Train {

    private final ChatModel chatModel;

    public Train(ChatModel chatModel) {
        this.chatModel = chatModel;
    }

    public String callAi(String prompt) {

        switch (prompt)
        {
            case "what is your name":
                return "hii i am your personal assistant JiJu ";
            default:
                return chatModel.call(prompt);
        }
    }
}
