import React from "react";

function RecipeComponent() {

    return (
            <h1>Recipe Finder</h1>
    );
}

export default RecipeComponent;